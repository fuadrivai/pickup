<?php

	// $connect = mysqli_connect('localhost', 'u7995957_admin', 'mhibs..', 'u7995957_pickup');
	$connect = mysqli_connect('localhost', 'root', '', 'pickup');
	if(mysqli_connect_error()){
		echo 'Gagal melakukan koneksi ke Database : '.mysqli_connect_error();
	}else{
	
	}

?>